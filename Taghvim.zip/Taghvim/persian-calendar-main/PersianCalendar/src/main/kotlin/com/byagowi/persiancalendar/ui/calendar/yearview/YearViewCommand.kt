package com.byagowi.persiancalendar.ui.calendar.yearview

enum class YearViewCommand { NextMonth, PreviousMonth, TodayMonth, ToggleYearSelection }
