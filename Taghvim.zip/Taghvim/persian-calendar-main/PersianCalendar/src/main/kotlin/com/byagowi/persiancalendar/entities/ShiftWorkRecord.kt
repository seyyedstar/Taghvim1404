package com.byagowi.persiancalendar.entities

data class ShiftWorkRecord(val type: String, val length: Int)
