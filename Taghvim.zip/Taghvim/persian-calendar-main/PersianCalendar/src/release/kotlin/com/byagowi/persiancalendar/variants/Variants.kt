package com.byagowi.persiancalendar.variants

@Suppress("UNUSED_PARAMETER")
fun debugLog(vararg message: Any?) = Unit // Nothing here

@Suppress("UNUSED_PARAMETER")
inline val <T> T.debugAssertNotNull: T inline get() = this // Nothing here
